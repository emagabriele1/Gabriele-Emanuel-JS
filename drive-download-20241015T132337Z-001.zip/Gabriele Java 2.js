var num1 = parseFloat(prompt('Primer numero: '));

var num2 = parseFloat(prompt('Segundo numero: '));

var sum = num1 + num2;


console.log('La suma es: ' + sum);
